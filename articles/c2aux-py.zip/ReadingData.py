def reading_one_line4(line):
    compt = 0
    j = 0
    int_stalk = ''
    test_list = []
    while compt < 4 and j < len(line):
        if line[j] != ' ':
            int_stalk = int_stalk + line[j]
            j += 1
        else:
            compt += 1
            test_list.append(int(int_stalk))
            int_stalk = ''
            j += 1
    return test_list

def reading_file_to_list4():
    with open('KreuzerSkarkeData4.txt') as f:
        lines4 = [line.rstrip() for line in f]
    lines4_formated = []
    for line in lines4:
        line = line[2:]
        line_formated = reading_one_line4(line)
        line_formated.append(line_formated[0] + line_formated[1] + line_formated[2] + line_formated[3])
        lines4_formated.append(line_formated)
    return lines4_formated

def reading_one_line5(line):
    compt = 0
    j = 0
    int_stalk = ''
    test_list = []
    while compt < 5 and j < len(line):
        if line[j] != ' ':
            int_stalk = int_stalk + line[j]
            j += 1
        else:
            compt += 1
            test_list.append(int(int_stalk))
            int_stalk = ''
            j += 1
    return test_list

def reading_file_to_list5():
    with open('KreuzerSkarkeData5.txt') as f:
        lines5 = [line.rstrip() for line in f]
    lines5_formated = []
    for line in lines5:
        line = line[2:]
        line_formated = reading_one_line5(line)
        lines5_formated.append(line_formated)
    return lines5_formated

def creates_data_list():
    return reading_file_to_list4() + reading_file_to_list5()

