from CalabiYauHypersurfacesWeighted import *
from ReadingData import *

data = creates_data_list()
""" print(check(data)) I executed it once,
it took 45 minutes but sent back True"""

data_regunfold = []
data_singcurve = []
data_regunfoldbutsingcurve = []
data_noedgebutsingcurve = []
data_noedgespecialinter2face = []

for d in data:
    n = d[0] + d[1] + d[2] + d[3] + d[4]
    a = unfold_has_sing_curve(n,d)
    b = has_sing_curve(n, d)
    c = has_edge(n, d)
    if b:
        data_singcurve.append(d)
    if not a:
        data_regunfold.append(d)
    if b and (not a):
        data_regunfoldbutsingcurve.append(d)
    if b and (not c):
        data_noedgebutsingcurve.append(d)
