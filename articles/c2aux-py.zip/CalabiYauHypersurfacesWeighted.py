import math

def partitions3(n, w):
    thelist = []
    for a_0 in range(n//w[0]+1):
        for a_1 in range(n//w[1]+1):
            for a_2 in range(n//w[2]+1):
                        if n == a_0*w[0] + a_1*w[1] + a_2*w[2]:
                            thelist.append((a_0,a_1,a_2))
    return thelist

def partitions(n, w):
    thelist = []
    for a_0 in range(n//w[0]+1):
        for a_1 in range(n//w[1]+1):
            for a_2 in range(n//w[2]+1):
                for a_3 in range(n//w[3]+1):
                    for a_4 in range(n//w[4]+1):
                        if n == a_0*w[0] + a_1*w[1] + a_2*w[2] + a_3*w[3] + a_4*w[4]:
                            thelist.append((a_0,a_1,a_2,a_3,a_4))
    return thelist

"""computes the highest common factor of elements in a list"""
def hcf(weights,exceptionallist):
    i = 0
    while i in exceptionallist:
        i += 1
    pgcd = weights[i]
    while i < len(weights):
        if i not in exceptionallist:
            pgcd = math.gcd(weights[i], pgcd)
        i += 1
    return pgcd

#Not to read necessarily: functions to check that KreuzerSkarke's data is right
#namely quasismooth wellformed

"""6.10 Fletcher"""
def wellformed(n, weights):
    for i in range(len(weights)):
        if hcf(weights, [i]) != 1:
            return False
        if i != 0:
            for j in range(i):
                if n % (hcf(weights, [i,j])) != 0:
                    return False
    return True

"""towards quasismoothness"""
def is_smaller(t,sup):
    for i in range(len(t)):
        if sup[i] == 0 and t[i] == 1:
            return False
    return True

""" -1 is like False, 42 is like actually is_smaller True,"""
""" i is the index where there is a single 1"""
def is_smaller_but_one(t, sup):
    pb = 0
    i_0 = 42
    for i in range(len(t)):
        if sup[i] == 0 and t[i] != 0:
            if t[i] != 1:
                return -1
            else:
                pb += 1
                i_0 = i
    if pb > 1:
        return -1
    return i_0
    

"""generates a list of tuples"""
def generates_Itotest():
    Itotest = []
    for k in range(1,32):
        a = k % 2
        b = (k // 2) % 2
        c = (k // 4) % 2
        d = (k // 8) % 2
        e = (k // 16) % 2
        Itotest.append((a, b, c, d, e))
    return Itotest

"""generates a list of tuples"""
def generates_Itotest3():
    Itotest = []
    for k in range(1,8):
        a = k % 2
        b = (k // 2) % 2
        c = (k // 4) % 2
        Itotest.append((a, b, c))
    return Itotest

"""updates Inottested by the information part gives"""
"""if a tuple has two ones, we have to find two helpers e_mu,"""
"""and we keep track of mu with the marker 2 in the tuple"""
def update(Inottested, part):
    i = 0
    while i < len(Inottested):
        track = is_smaller_but_one(part, Inottested[i])
        if track == 42:
            trash = Inottested.pop(i)
        elif track == -1:
            i += 1
        else:
            k = Inottested[i].count(1)
            if k == 1:
                trash = Inottested.pop(i)
            elif k >= 3:
                i += 1
            elif k == 2:
                if Inottested[i][track] == 2:
                    i += 1
                elif Inottested[i].count(2) == 1:
                    trash = Inottested.pop(i)
                else:
                    Inottested[i] = Inottested[i][:track] + (2,) + Inottested[i][track + 1:]
                    i += 1
    return Inottested
            
    

def quasismooth(n, weights):
    thelist = partitions(n, weights)
    Inottested = generates_Itotest()
    j = 0
    while len(Inottested) != 0 and j < len(thelist):
        part = thelist[j]
        Inottested = update(Inottested, part)
        j += 1
    return len(Inottested) == 0

def quasismooth3(n, weights):
    thelist = partitions3(n, weights)
    Inottested = generates_Itotest3()
    j = 0
    while len(Inottested) != 0 and j < len(thelist):
        part = thelist[j]
        Inottested = update(Inottested, part)
        j += 1
    return len(Inottested) == 0


""" never use that, it takes forever,
and now we have the data of KreuzerSkarke """
def big_data(topvalue):
    data_list = []
    for w_4 in range(1,topvalue):
        for w_3 in range(1, w_4 + 1):
            for w_2 in range(1, w_3 + 1):
                for w_1 in range(1, w_2 + 1):
                    for w_0 in range(1, w_1 + 1):
                        n = w_0 + w_1 + w_2 + w_3 + w_4
                        weights = [w_0,w_1,w_2,w_3,w_4]
                        if wellformed(n,weights) and quasismooth(n, weights):
                            data_list.append(weights)
    return data_list



def check(data):
    for i in range(len(data)):
        d = data[i]
        if i % 100 == 0:
            print(i)
            print(' ')
        n = d[0] + d[1] + d[2] +d[3] + d[4]
        if not wellformed(n, d) or not quasismooth(n, d):
             return False
    return True

# Looking for singular curves in these Calabi-Yaus

""" two types of singular curves of X:
- singular edges of P that are contained in X :
    eg [0:0:0::] in (1,1,1,2,2)
    of type 1/2 (1,1)
- singular simplicial surfaces of P (triangles) that intersect X:
    eg [0:0:::] in (1,1,2,2,2) intersects X along a curve
    which is like X_8 in P(2,2,2),
    ie isomorphic to a general quartic in P^3
    but of type 1/2 (1,1) in X """

"""w of length 5"""
""" returns the set of singular edges, truly singular or global quotients,
in the form
(the boolean "is a true singular curve", not resolved by saying P is a quotient of the smooth proj,
the quotient degree of the curve in X,
the two non-zero indices)"""
def threepgcd_twopgcd(w):
    thpgcd = []
    thpgcdplace = []
    twpgcd = []
    twpgcdplace = []
    for i in range(1, 5):
        for j in range(i):
            pgcdij = math.gcd(w[i],w[j])
            if pgcdij != 1:
                twpgcd.append(pgcdij)
                twpgcdplace.append((i,j))
            if j != 0:
                for k in range(j):
                    pgcdijk = math.gcd(pgcdij,w[k])
                    if pgcdijk != 1:
                        thpgcd.append(pgcdijk)
                        thpgcdplace.append((i,j,k))
    return (thpgcd,thpgcdplace,twpgcd,twpgcdplace)


def no_one_in(w):
    for i in range(5):
        if w[i] == 1:
            return False
    return True

def partitionable(n, u, v):
    for a in range(n//u + 1):
        if (n - a*u) % v == 0:
            return True
    return False

def has_edge(n, w):
    for a in range(5):
        for b in range(a):
            if not partitionable(n, w[a], w[b]):
                return True
    return False

def edges(n, w):
    edges = []
    for a in range(5):
        for b in range(a):
            if not partitionable(n, w[a], w[b]):
                edges.append((a,b))
    return edges

def is_in(e,f):
    return (e[0] == f[0] and e[1] == f[1]) or (e[0] == f[0] and e[1] == f[2]) or (e[0] == f[1] and e[1] == f[2])

def singular_edges(n, w):
    sing_edges = []
    all_pgcd = threepgcd_twopgcd(w)
    twpgcd, twpgcdplace = all_pgcd[2], all_pgcd[3]
    for i in range(len(twpgcd)):
        a, b = twpgcdplace[i][0], twpgcdplace[i][1]
        if not partitionable(n, w[a], w[b]):
            truly_sing = no_one_in(w) or not partitionable(n-1,w[a],w[b])
            sing_edges.append((truly_sing,twpgcd[i],a,b))
    return sing_edges

def has_truly_sing_curve(n, w):
    all_pgcd = threepgcd_twopgcd(w)
    twpgcd, twpgcdplace = all_pgcd[2], all_pgcd[3]
    for i in range(len(twpgcd)):
        a, b = twpgcdplace[i][0], twpgcdplace[i][1]
        if not partitionable(n, w[a], w[b]):
            truly_sing = no_one_in(w) or not partitionable(n-1,w[a],w[b])
            if truly_sing:
                return True
    return False

""" looks for edges that are in Xnot in X_sing but with preimage in hat(X)_sing """
def unfold_has_sing_curve(n, w):
    for a in range(5):
        for b in range(a):
            if not partitionable(n, w[a], w[b]):
                truly_sing = no_one_in(w) or not partitionable(n-1,w[a],w[b])
                if truly_sing:
                    return True
    return False

""" maintenant on veut comprendre l'autre type de courbes singulières
premièrement, on peut montrer qu'une courbe vraiment singulière
(ie singulière après revêtement quotient de P^4)
a toujours trois 0, en fait """

def singular_other_curves(n, w):
    sing_curv = []
    all_pgcd = threepgcd_twopgcd(w)
    thpgcd, thpgcdplace = all_pgcd[0], all_pgcd[1]
    for i in range(len(thpgcd)):
        a, b, c = thpgcdplace[i][0], thpgcdplace[i][1], thpgcdplace[i][2]
        """ X quasismooth montre que toute une surface singulière
            de P coupe vraiment X le long de quelque chose de généralement
            réduit irréductible de dim 1 """
        sing_curv.append((thpgcd[i],a,b,c))
    return sing_curv
        
def has_sing_curve(n, w):
    return len(threepgcd_twopgcd(w)[0]) != 0 or len(singular_edges(n, w)) != 0

def specialinter2(n, w):
    for a in range(5):
        for b in range(a):
            for c in range(b):
                if not quasismooth3(n,[w[a],w[b],w[c]]):
                    return True
    return False
                                   
